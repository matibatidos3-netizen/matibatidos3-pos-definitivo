# Matibatidos POS - no custom ProGuard rules required.
