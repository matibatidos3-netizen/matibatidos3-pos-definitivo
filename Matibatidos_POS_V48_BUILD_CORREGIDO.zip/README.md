# Matibatidos POS — Android

Base: Matibatidos POS V48 Turno Seguro.

## Qué incluye
- Sistema HTML completo dentro de `app/src/main/assets/index.html`.
- WebView Android con JavaScript y almacenamiento local.
- Back navigation.
- Descarga de archivos/reportes mediante DownloadManager.
- Impresión mediante Android PrintManager.
- Orientación no bloqueada: funciona vertical/horizontal según el dispositivo.
- El sistema funciona offline porque la interfaz principal está incluida dentro del APK.

## Generar el APK
Abrir esta carpeta en Android Studio y esperar a que sincronice Gradle.

Para una versión de prueba:
`Build > Build APK(s)`

Para una versión firmada:
`Build > Generate Signed Bundle / APK > APK`

El APK de debug normalmente queda en:
`app/build/outputs/apk/debug/app-debug.apk`

## Nota
Este entorno no tiene instalado Android SDK/Build Tools, por lo que aquí no fue posible compilar el binario APK final. El proyecto está preparado para compilarse en Android Studio.
